#include "monomarith.h"
#include "polyarith.h"

monxyz  NULLMONXYZ =
{
    0.0,
    0,
    0,
    0
};

monxyz  ONEMONXYZ =
{
    1.0,
    0,
    0,
    0
};

polyxyz NULLPOLYXYZ =
{
	0,
	0,
	0,
};

int surface_run_commands   = FALSE;
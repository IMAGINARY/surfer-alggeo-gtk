/* acconfig.h
 * This file is in the public domain.
 * 
 * Descriptive text for the C preprocessor macros that
 * the distributed Autoconf macros can define.
 * These entries are sometimes used by macros
 * which glade-- uses.
 */
#undef PACKAGE
#undef VERSION
